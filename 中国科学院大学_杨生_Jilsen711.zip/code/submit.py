import json
# 此类会被跑分服务器继承， 可以在类中自由添加自己的prompt构建逻辑, 除了parse_table 和 run_inference_llm 两个方法不可改动
# 注意千万不可修改类名和下面已提供的三个函数名称和参数， 这三个函数都会被跑分服务器调用
class submission():
    def __init__(self, table_meta_path):
        self.table_meta_path = table_meta_path

    # 此函数不可改动, 与跑分服务器端逻辑一致， 返回值 grouped_by_db_id 是数据库的元数据（包含所有验证测试集用到的数据库）
    # 请不要对此函数做任何改动
    def parse_table(self, table_meta_path):
        with open(table_meta_path,'r') as db_meta:
            db_meta_info = json.load(db_meta)
        # 创建一个空字典来存储根据 db_id 分类的数据
        grouped_by_db_id = {}

        # 遍历列表中的每个字典
        for item in db_meta_info:
            # 获取当前字典的 db_id
            db_id = item['db_id']
            
            # 如果 db_id 已存在于字典中，将当前字典追加到对应的列表
            if db_id in grouped_by_db_id:
                grouped_by_db_id[db_id].append(item)
            # 如果 db_id 不在字典中，为这个 db_id 创建一个新列表
            else:
                grouped_by_db_id[db_id] = [item]
        return grouped_by_db_id

    # 此为选手主要改动的逻辑， 此函数会被跑分服务器调用，用来构造最终输出给模型的prompt， 并对模型回复进行打分。
    # 当前提供了一个最基础的prompt模版， 选手需要对其进行改进
    
    def construct_prompt(self, current_user_question):
        import re
        import pandas as pd
        question_type = current_user_question['question_type']
        user_question = current_user_question['user_question']
        system_prompt = f'''
       
        '''
        if question_type == 'text2sql':
            current_db_id = current_user_question['db_id']
            cur_db_info = self.parse_table(self.table_meta_path)[current_db_id]
            data = cur_db_info[0]
            def extract_question_answer(text):
                pattern = r'The questions = \["(.+?)"\]'
                match = re.search(pattern, text)
                return match.group(1) if match else None
            def extract_first_schema_link(text):
                pattern = r'Schema_links:\s*\[[^\]]*\]'
                match = re.search(pattern, text)
                return match.group(0) if match else None
            def extract_first_label(text):
                pattern = r'Label:\s*"([^"]*)"'
                match = re.search(pattern, text)
                return match.group(0) if match else None
            def extract_first_sql_statement(text):
                pattern = r'SQL:\s*(SELECT.*?)(?=\s*[A-Z]{2,}:|$)'
                match = re.search(pattern, text, flags=re.S)  
                return match.group(1) if match else None
            # cur_db_info_str = str(cur_db_info)
            # columns = [column[1] for column in data["column_names_original"]]
            def reformat_schema(schema):
                table_names = schema['table_names_original']
                column_names = schema['column_names_original']
                foreign_keys = schema['foreign_keys']
                primary_keys = schema['primary_keys']
                
                # 创建用于存储表格式字符串的列表
                tables_str = []
                schema_list = []
                f_keys = []
                p_keys = []
                # 按表名处理每个表的列名
                for i, table_name in enumerate(table_names):
                    # 提取此表的所有列名
                    columns = [col[1] for col in column_names if col[0] == i]
                    # 构造表字符串
                    table_str = f"Table {table_name}, columns = [*, " + ", ".join(columns) + "]"
                    tables_str.append(table_str)
                    for col in columns:
                        schema_list.append([schema['db_id'], table_name, col])
                # 构造外键字符串
                foreign_keys_str = "Foreign_keys = ["
                for fk in foreign_keys:
                    # 找到外键对应的表名和列名
                    child_col = column_names[fk[0]][1]
                    parent_col = column_names[fk[1]][1]
                    child_table = table_names[column_names[fk[0]][0]]
                    parent_table = table_names[column_names[fk[1]][0]]
                    
                    # 添加外键关系到列表
                    foreign_keys_str += f"{child_table}.{child_col} = {parent_table}.{parent_col}, "
                    f_keys.append([schema['db_id'], child_table, parent_table, child_col, parent_col])
                # 移除最后的逗号和空格
                if foreign_keys_str.endswith(", "):
                    foreign_keys_str = foreign_keys_str[:-2]
                foreign_keys_str += "]"
                primary_keys_str = "Primary_keys = ["
                for pk in primary_keys:
                    table_idx = column_names[pk][0]
                    col_name = column_names[pk][1]
                    table_name = table_names[table_idx]
                    
                    primary_keys_str += f"{table_name}.{col_name}, "
                    p_keys.append([schema['db_id'], table_name, col_name])
                spider_schema = pd.DataFrame(schema_list, columns=['Database name', 'Table Name', 'Field Name'])
                spider_primary = pd.DataFrame(p_keys, columns=['Database name', 'Table Name', 'Primary Key'])
                spider_foreign = pd.DataFrame(f_keys, columns=['Database name', 'First Table Name', 'Second Table Name', 'First Table Foreign Key', 'Second Table Foreign Key'])
                # 汇总所有信息
                # print(spider_schema)
                # print(spider_primary)
                # print(spider_foreign)
                return "\n".join(tables_str), foreign_keys_str,primary_keys_str,spider_schema,spider_primary,spider_foreign
            table_str, foreign_keys_str, primary_keys_str,spider_schema,spider_primary,spider_foreign  = reformat_schema(data)
            # foreign_keys = data["foreign_keys"]
            # primary_keys = data["primary_keys"]
            # columns_result = f"columns = [{','.join(columns)}]"
            # foreign_keys_result = str(foreign_keys)
            
            system_prompt += f'''
            '''
            schema_linking_prompt = f'''
            # Find the schema_links for generating SQL queries for each question based on the database schema and Foreign keys.\n"
            
            Table department, columns = [*,Department_ID,Name,Creation,Ranking,Budget_in_Billions,Num_Employees]
            Table head, columns = [*,head_ID,name,born_state,age]
            Table management, columns = [*,department_ID,head_ID,temporary_acting]
            Foreign_keys = [management.head_ID = head.head_ID,management.department_ID = department.Department_ID]
            Q: "How many heads of the departments are older than 56 ?"
            A: Let’s think step by step. In the question "How many heads of the departments are older than 56 ?", we are asked:
            "How many heads of the departments" so we need column = [head.*]
            "older" so we need column = [head.age]
            Based on the columns and tables, we need these Foreign_keys = [].
            Based on the tables, columns, and Foreign_keys, The set of possible cell values are = [56]. So the Schema_links are:
            Schema_links: [head.*,head.age,56]

            Table city, columns = [*,City_ID,Official_Name,Status,Area_km_2,Population,Census_Ranking]
            Table competition_record, columns = [*,Competition_ID,Farm_ID,Rank]
            Table farm, columns = [*,Farm_ID,Year,Total_Horses,Working_Horses,Total_Cattle,Oxen,Bulls,Cows,Pigs,Sheep_and_Goats]
            Table farm_competition, columns = [*,Competition_ID,Year,Theme,Host_city_ID,Hosts]
            Foreign_keys = [farm_competition.Host_city_ID = city.City_ID,competition_record.Farm_ID = farm.Farm_ID,competition_record.Competition_ID = farm_competition.Competition_ID]
            Q: "Show the status of the city that has hosted the greatest number of competitions."
            A: Let’s think step by step. In the question "Show the status of the city that has hosted the greatest number of competitions.", we are asked:
            "the status of the city" so we need column = [city.Status]
            "greatest number of competitions" so we need column = [farm_competition.*]
            Based on the columns and tables, we need these Foreign_keys = [farm_competition.Host_city_ID = city.City_ID].
            Based on the tables, columns, and Foreign_keys, The set of possible cell values are = []. So the Schema_links are:
            Schema_links: [city.Status,farm_competition.Host_city_ID = city.City_ID,farm_competition.*]

            Table city, columns = [*,City_ID,Official_Name,Status,Area_km_2,Population,Census_Ranking]
            Table competition_record, columns = [*,Competition_ID,Farm_ID,Rank]
            Table farm, columns = [*,Farm_ID,Year,Total_Horses,Working_Horses,Total_Cattle,Oxen,Bulls,Cows,Pigs,Sheep_and_Goats]
            Table farm_competition, columns = [*,Competition_ID,Year,Theme,Host_city_ID,Hosts]
            Foreign_keys = [farm_competition.Host_city_ID = city.City_ID,competition_record.Farm_ID = farm.Farm_ID,competition_record.Competition_ID = farm_competition.Competition_ID]
            Q: "Show the status shared by cities with population bigger than 1500 and smaller than 500."
            A: Let’s think step by step. In the question "Show the status shared by cities with population bigger than 1500 and smaller than 500.", we are asked:
            "the status shared by cities" so we need column = [city.Status]
            "cities with population" so we need column = [city.Population]
            Based on the columns and tables, we need these Foreign_keys = [].
            Based on the tables, columns, and Foreign_keys, The set of possible cell values are = [1500,500]. So the Schema_links are:
            Schema_links: [city.Status,city.Population,1500,500]

            {table_str}\n
            {foreign_keys_str}
            Q:{user_question}.
            A: Let’s think step by step.
            Schema_links:
            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": schema_linking_prompt}
            ]
            answer1 =self.run_inference_llm(messages)
            answer1_txt = extract_first_schema_link(answer1)
            system_prompt = f'''
            你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
            "The questions = [] "
            "Label: "
            请在回答包含下面两组字样
            "The questions = []"
            "Label: "
            请在回答包含下面两组字样
            "The questions = []"
            "Label: "
            因为我需要分析中间过程。谢谢
            '''
            user_prompt = f'''
            # For the given question, classify it as EASY, NON-NESTED, or NESTED based on nested queries and JOIN.
            You must choose one from these three options.
            if don't need JOIN and don't need nested queries: predict Label: "EASY".
            elif need JOIN and don't need nested queries: predict Label: "NON-NESTED"
            elif need nested queries: predict Label: "NESTED"
            You must choose one from these three options.
            
            Table advisor, columns = [*,s_ID,i_ID]
            Table classroom, columns = [*,building,room_number,capacity]
            Table course, columns = [*,course_id,title,dept_name,credits]
            Table department, columns = [*,dept_name,building,budget]
            Table instructor, columns = [*,ID,name,dept_name,salary]
            Table prereq, columns = [*,course_id,prereq_id]
            Table section, columns = [*,course_id,sec_id,semester,year,building,room_number,time_slot_id] Table student, columns = [*,ID,name,dept_name,tot_cred]
            Table takes, columns = [*,ID,course_id,sec_id,semester,year,grade]
            Table teaches, columns = [*,ID,course_id,sec_id,semester,year]
            Table time_slot, columns = [*,time_slot_id,day,start_hr,start_min,end_hr,end_min]
            Foreign_keys = [course.dept_name = department.dept_name,instructor.dept_name = de- partment.dept_name,section.building = classroom.building,section.room_number = class- room.room_number,
            section.course_id = course.course_id,teaches.ID = instructor.ID,teaches.course_id = sec- tion.course_id,teaches.sec_id = section.sec_id,teaches.semester = section.semester,
            teaches.year = section.year,student.dept_name = department.dept_name,takes.ID = stu- dent.ID,takes.course_id = section.course_id,takes.sec_id = section.sec_id,takes.semester = section.semester,takes.year = section.year,advisor.s_ID = student.ID,
            advisor.i_ID = instructor.ID,prereq.prereq_id = course.course_id,prereq.course_id = course.course_id]
            
            Q: "Find the buildings which have rooms with capacity more than 50."
            schema_links: [classroom.building,classroom.capacity,50]
            A: Let’s think step by step. The SQL query for the question "Find the buildings which have rooms with capacity more than 50." needs these tables = [classroom], so we don't need JOIN.
            Plus, it doesn't require nested queries with (INTERSECT, UNION, EXCEPT, IN, NOT IN), and we need the answer to 
            The questions = [""].
            So, we don't need JOIN and don't need nested queries, then the the SQL query can be classified as "EASY".
            Label: "EASY"

            Q: "What are the names of all instructors who advise students in the math depart sorted by total credits of the student."
            schema_links: [advisor.i_id = instructor.id,advisor.s_id = student.id,instructor.name,student.dept_name,student.tot_cred,math]
            A: Let’s think step by step. The SQL query for the question "What are the names of all instructors who advise students in the math depart sorted by total credits of the student." needs these tables = [advisor,instructor,student], so we need JOIN.
            Plus, it doesn't need nested queries with (INTERSECT, UNION, EXCEPT, IN, NOT IN), and we need the answer to 
            The questions = [""].
            So, we need JOIN and don't need nested queries, then the the SQL query can be classified as "NON-NESTED".
            Label: "NON-NESTED"

            Q: "Find the id of instructors who taught a class in Fall 2009 but not in Spring 2010."
            schema_links: [teaches.id,teaches.semester,teaches.year,Fall,2009,Spring,2010]
            A: Let’s think step by step. The SQL query for the question "Find the id of instructors who taught a class in Fall 2009 but not in Spring 2010." needs these tables = [teaches], so we don't need JOIN.
            Plus, it requires nested queries with (INTERSECT, UNION, EXCEPT, IN, NOT IN), and we need the answer to 
            The questions = ["Find the id of instructors who taught a class in Spring 2010"].
            So, we don't need JOIN and need nested queries, then the the SQL query can be classified as "NESTED".
            Label: "NESTED"

            {table_str}
            Q:"{user_question}"
            {answer1_txt}
            A: Let’s think step by step.
            The questions =
            Label:
            
            你是一个注重细节的助手，请你通过上下文学习，在你的回答中包含
            "The questions = "
            "Label: "EASY"/"NESTED"/"NON-NESTED""
            字样，这能帮助我分析，谢谢
            EASY, NON-NESTED, or NESTED
            你必须选择一个Label给这个问题贴上标签，
            例如：Label: "EASY"，Label: "NESTED"，Label: "NON-NESTED"
            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
            answer2 =self.run_inference_llm(messages)
            answer2_txt = extract_first_label(answer2)
            answer2_1txt = extract_question_answer(answer2)
            if answer2_txt == 'Label: "EASY"':
                
                system_prompt = f'''
                你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                因为我需要分析中间过程。谢谢
                #例如
                Q: "Find the department name of the instructor whose name contains 'Soisalon'."
                Schema_links: [instructor.dept_name,instructor.name,Soisalon]
                SQL: SELECT dept_name FROM instructor WHERE name LIKE '%Soisalon%'
                
                Q: "How many instructors teach a course in the Spring of 2010?"
                Schema_links: [teaches.ID,teaches.semester,teaches.YEAR,Spring,2010]
                SQL: SELECT COUNT (DISTINCT ID) FROM teaches WHERE semester  =  'Spring' AND YEAR  =  2010
                
                Q: "How many rooms in each building have a capacity of over 50?"
                Schema_links: [classroom.*,classroom.building,classroom.capacity,50]
                SQL: SELECT count(*) ,  building FROM classroom WHERE capacity  >  50 GROUP BY building
                '''
                user_prompt = f'''
                # 使用 schema links 为每个问题生成 SQL 查询。避免冗余查询，请给出一个直接、高效的SQL
                #例如：
                Q: "Find the buildings which have rooms with capacity more than 50."
                Schema_links: [classroom.building,classroom.capacity,50]
                SQL: SELECT DISTINCT building FROM classroom WHERE capacity  >  50

                Q: "Find the room number of the rooms which can sit 50 to 100 students and their buildings."
                Schema_links: [classroom.building,classroom.room_number,classroom.capacity,50,100]
                SQL: SELECT building ,  room_number FROM classroom WHERE capacity BETWEEN 50 AND 100

                Q: "Give the name of the student in the History department with the most credits."
                Schema_links: [student.name,student.dept_name,student.tot_cred,History]
                SQL: SELECT name FROM student WHERE dept_name  =  'History' ORDER BY tot_cred DESC LIMIT 1

                Q: "Find the total budgets of the Marketing or Finance department."
                Schema_links: [department.budget,department.dept_name,Marketing,Finance]
                SQL: SELECT sum(budget) FROM department WHERE dept_name  =  'Marketing' OR dept_name  =  'Finance'

    
                {table_str}
                Q: "{user_question}"
                {answer1_txt}
                SQL:
                你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                因为我需要分析中间过程。谢谢
                #例如
                '''
            elif answer2_txt == 'Label: "NON-NESTED"':
                
                system_prompt = f'''
                你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                因为我需要分析中间过程。谢谢
                #例如
                

                Q: "Find the name of students who took any class in the years of 2009 and 2010."
                Schema_links: [student.name,student.id = takes.id,takes.YEAR,2009,2010]
                A: Let’s think step by step. For creating the SQL for the given question, we need to join these tables = [student,takes]. First, create an intermediate representation, then use it to construct the SQL query.
                Intermediate_representation: select  distinct student.name from student  where  takes.year = 2009  or  takes.year = 2010
                SQL: SELECT DISTINCT T1.name FROM student AS T1 JOIN takes AS T2 ON T1.id  =  T2.id WHERE T2.YEAR  =  2009 OR T2.YEAR  =  2010
                
                Q: "list in alphabetic order all course names and their instructors' names in year 2008."
                Schema_links: [course.title,course.course_id = teaches.course_id,teaches.id = instructor.id,instructor.name,teaches.year,2008]
                A: Let’s think step by step. For creating the SQL for the given question, we need to join these tables = [course,teaches,instructor]. First, create an intermediate representation, then use it to construct the SQL query.
                Intermediate_representation: select course.title , instructor.name from course  where  teaches.year = 2008  order by course.title asc
                SQL: SELECT T1.title ,  T3.name FROM course AS T1 JOIN teaches AS T2 ON T1.course_id  =  T2.course_id JOIN instructor AS T3 ON T2.id  =  T3.id WHERE T2.YEAR  =  2008 ORDER BY T1.title
                '''
                user_prompt = f'''
                # 使用 schema links 和 Intermediate_representation 来为每个问题生成 SQL 查询。避免冗余查询，请给出一个直接、高效的SQL
                #例如：
                Q: "Find the name and building of the department with the highest budget."
                Schema_links: [department.budget,department.dept_name,department.building]
                A: Let’s think step by step. For creating the SQL for the given question, we need to join these tables = []. First, create an intermediate representation, then use it to construct the SQL query.
                Intermediate_representation: select department.dept_name , department.building from department  order by department.budget desc limit 1
                SQL: SELECT dept_name ,  building FROM department ORDER BY budget DESC LIMIT 1

                Q: "Find the total number of students and total number of instructors for each department."
                Schema_links: [department.dept_name = student.dept_name,student.id,department.dept_name = instructor.dept_name,instructor.id]
                A: Let’s think step by step. For creating the SQL for the given question, we need to join these tables = [department,student,instructor]. First, create an intermediate representation, then use it to construct the SQL query.
                Intermediate_representation: "select count( distinct student.ID) , count( distinct instructor.ID) , department.dept_name from department  group by instructor.dept_name
                SQL: SELECT count(DISTINCT T2.id) ,  count(DISTINCT T3.id) ,  T3.dept_name FROM department AS T1 JOIN student AS T2 ON T1.dept_name  =  T2.dept_name JOIN instructor AS T3 ON T1.dept_name  =  T3.dept_name GROUP BY T3.dept_name

                Q: "Find the title of courses that have two prerequisites?"
                Schema_links: [course.title,course.course_id = prereq.course_id]
                A: Let’s think step by step. For creating the SQL for the given question, we need to join these tables = [course,prereq]. First, create an intermediate representation, then use it to construct the SQL query.
                Intermediate_representation: select course.title from course  where  count ( prereq.* )  = 2  group by prereq.course_id
                SQL: SELECT T1.title FROM course AS T1 JOIN prereq AS T2 ON T1.course_id  =  T2.course_id GROUP BY T2.course_id HAVING count(*)  =  2
                
                {table_str}
                {foreign_keys_str}
                Q: "{user_question}"
                {answer1_txt}
                A:
                SQL:
                你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                因为我需要分析中间过程。谢谢
                '''
            else:
                system_prompt = f'''
                你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                因为我需要分析中间过程,这对我很关键哦。谢谢
                #例如
                
                Q: "Find the name and building of the department with the highest budget."
                Schema_links: [department.dept_name,department.building,department.budget]
                A: Let's think step by step. "Find the name and building of the department with the highest budget." can be solved by knowing the answer to the following sub-question "What is the department name and corresponding building for the department with the greatest budget?".
                The SQL query for the sub-question "What is the department name and corresponding building for the department with the greatest budget?" is SELECT dept_name ,  building FROM department ORDER BY budget DESC LIMIT 1
                So, the answer to the question "Find the name and building of the department with the highest budget." is =
                Intermediate_representation: select department.dept_name , department.building from department  order by department.budget desc limit 1
                SQL: SELECT dept_name ,  building FROM department ORDER BY budget DESC LIMIT 1
                SQL: SELECT T2.name ,  T2.location FROM race AS T1 JOIN track AS T2 ON T1.track_id  =  T2.track_id GROUP BY T1.track_id HAVING count(*)  =  1
                
                Q: "Give the title and credits for the course that is taught in the classroom with the greatest capacity."
                Schema_links: [classroom.capacity,classroom.building = SECTION.building,classroom.room_number = SECTION.room_number,course.title,course.credits,course.course_id = SECTION.course_id]
                A: Let's think step by step. "Give the title and credits for the course that is taught in the classroom with the greatest capacity." can be solved by knowing the answer to the following sub-question "What is the capacity of the largest room?".
                The SQL query for the sub-question "What is the capacity of the largest room?" is (SELECT max(capacity) FROM classroom)
                So, the answer to the question "Give the title and credits for the course that is taught in the classroom with the greatest capacity." is =
                Intermediate_representation: select course.title , course.credits from classroom  order by classroom.capacity desc limit 1"
                SQL: SELECT T3.title ,  T3.credits FROM classroom AS T1 JOIN SECTION AS T2 ON T1.building  =  T2.building AND T1.room_number  =  T2.room_number JOIN course AS T3 ON T2.course_id  =  T3.course_id WHERE T1.capacity  =  (SELECT max(capacity) FROM classroom)
                '''
                user_prompt = f'''
                # 使用intermediate representation和 schema links 为每个问题生成 SQL 查询。避免冗余查询，请给出一个直接、高效的SQL
                #例如：

                Q: "Find the id of instructors who taught a class in Fall 2009 but not in Spring 2010."
                Schema_links: [teaches.id,teaches.semester,teaches.YEAR,Fall,2009,Spring,2010]
                A: Let's think step by step. "Find the id of instructors who taught a class in Fall 2009 but not in Spring 2010." can be solved by knowing the answer to the following sub-question "Find the id of instructors who taught a class in Spring 2010".
                The SQL query for the sub-question "Find the id of instructors who taught a class in Spring 2010" is SELECT id FROM teaches WHERE semester  =  'Spring' AND YEAR  =  2010
                So, the answer to the question "Find the id of instructors who taught a class in Fall 2009 but not in Spring 2010." is = 
                Intermediate_representation: select teaches.ID from teaches  where  teaches.semester = \"Fall\"  and  teaches.year = 2009  and  teaches.semester != \"Spring\"  and  teaches.year = 2010 
                SQL: SELECT id FROM teaches WHERE semester  =  'Fall' AND YEAR  =  2009 EXCEPT SELECT id FROM teaches WHERE semester  =  'Spring' AND YEAR  =  2010

                Q: "Find the name of the courses that do not have any prerequisite?"
                Schema_links: [course.title,course.course_id]
                A: Let's think step by step. "Find the name of the courses that do not have any prerequisite?" can be solved by knowing the answer to the following sub-question "What are the courses that have any prerequisite?".
                The SQL query for the sub-question "What are the courses that have any prerequisite?" is SELECT course_id FROM prereq
                So, the answer to the question "Find the name of the courses that do not have any prerequisite?" is =
                Intermediate_representation: select course.title from course  where  @.@ not in prereq.course_id 
                SQL: SELECT title FROM course WHERE course_id NOT IN (SELECT course_id FROM prereq)

                Q: "Find the salaries of all distinct instructors that are less than the largest salary."
                Schema_links: [instructor.salary]
                A: Let's think step by step. "Find the salaries of all distinct instructors that are less than the largest salary." can be solved by knowing the answer to the following sub-question "What is the largest salary of instructors".
                The SQL query for the sub-question "What is the largest salary of instructors" is SELECT max(salary) FROM instructor
                So, the answer to the question "Find the salaries of all distinct instructors that are less than the largest salary." is =
                Intermediate_representation: select  distinct instructor.salary from instructor  where  @.@ < max ( instructor.salary )
                SQL: SELECT DISTINCT salary FROM instructor WHERE salary  <  (SELECT max(salary) FROM instructor)

                Q: "Find the names of students who have taken any course in the fall semester of year 2003."
                Schema_links: [student.id,student.name,takes.id,takes.semester,fall,2003]
                A: Let's think step by step. "Find the names of students who have taken any course in the fall semester of year 2003." can be solved by knowing the answer to the following sub-question "Find the students who have taken any course in the fall semester of year 2003.".
                The SQL query for the sub-question "Find the students who have taken any course in the fall semester of year 2003." is SELECT id FROM takes WHERE semester  =  'Fall' AND YEAR  =  2003
                So, the answer to the question "Find the names of students who have taken any course in the fall semester of year 2003." is =
                Intermediate_representation: select student.name from student  where  takes.semester = \"Fall\"  and  takes.year = 2003
                SQL: SELECT name FROM student WHERE id IN (SELECT id FROM takes WHERE semester  =  'Fall' AND YEAR  =  2003)

                {table_str}
                {foreign_keys_str}
                Q:{user_question}
                {answer1_txt}
                A: Let's think step by step. "{user_question}"can be solved by knowing the answer to the following sub-question."{answer2_1txt}".The SQL query for the sub-question.
                SQL:
                你是一个注重过程的助手，请你通过上下文学习，在你的回答中包含
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                请在回答包含下面一组字样
                "SQL: "
                因为我需要分析中间过程。谢谢。
                给出SQL语句时，像上面的例子一样，直接给出答案，不要添加其他任何符号与语句
                
                '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
            answer3 =self.run_inference_llm(messages)
            answer3_txt = extract_first_sql_statement(answer3)
            system_prompt = f'''
            
            你是一位数据库专家，对于给定的问题{user_question}，使用生成的{answer3_txt}.在提供的表格、列、外键和主键
            {table_str}\n
            {foreign_keys_str}\n
            {primary_keys_str}\n
            来模拟查询并判断是否存在语法问题，然后修复给定的 SQLite SQL语句的存在的任何问题。
            如果存在问题或者SQL冗余查询(考虑IN的使用)，请进行修复它们。如果没有问题，则返回SQL语句.
            
    
            请你只返回给我SQL，不要有任何其他符号或文字，包括句号、逗号等。
            '''
            user_prompt = f'''
            使用以下指导原则修复 SQL 查询:
                    1) Use the database values that are explicitly mentioned in the question.
                    2) Pay attention to the columns that are used for the JOIN by using the Foreign_keys.
                    3) Use DESC and DISTINCT when needed.
                    4) Pay attention to the columns that are used for the GROUP BY statement.
                    5) Pay attention to the columns that are used for the SELECT statement.
                    6) Only change the GROUP BY clause when necessary (Avoid redundant columns in GROUP BY).
                    7) Use GROUP BY on one column only.
                    8) Consider using INTERSECT for combining results.
                    9) Avoid using IN for redundant queries.
            为了避免程序错误，请你只返回给我SQL，不要有任何其他符号或文字，包括句号、逗号等。
            #例如：
            问题: Eric C. Kerrigan 's Liquid Automatica paper
            SQLite SQL QUERY:  SELECT DISTINCT paper.title FROM paper JOIN writes ON paper.paperId = writes.paperId JOIN author ON writes.authorId = author.authorId WHERE author.authorName  =  'Eric C. Kerrigan' AND venue.venueName  =  'Liquid Automatica'
            输出:SELECT DISTINCT t2.paperid FROM paperkeyphrase AS t5 JOIN keyphrase AS t3 ON t5.keyphraseid  =  t3.keyphraseid JOIN writes AS t4 ON t4.paperid  =  t5.paperid JOIN paper AS t2 ON t4.paperid  =  t2.paperid JOIN author AS t1 ON t4.authorid  =  t1.authorid JOIN venue AS t6 ON t6.venueid  =  t2.venueid WHERE t1.authorname  =  "Eric C. Kerrigan" AND t3.keyphrasename  =  "Liquid" AND t6.venuename  =  "Automatica"
            
            问题: 既有吨位大于6000的船舶又有吨位小于4000的船舶的船舶类型是什么？
            SQLite SQL QUERY: SELECT DISTINCT ship.Type FROM ship 
            WHERE Tonnage > 6000 OR Tonnage < 4000
            输出:SELECT TYPE FROM ship WHERE Tonnage  >  6000 INTERSECT SELECT TYPE FROM ship WHERE Tonnage  <  4000
            
            问题: 拥有超过50名球员的国家的代码是什么？
            SQLite SQL QUERY: SELECT DISTINCT country_code FROM players WHERE player_id IN (SELECT player_id FROM matches GROUP BY winner_id HAVING COUNT(*) > 50)
            输出: SELECT country_code FROM players GROUP BY country_code HAVING count(*)  >  50
            {table_str}\n
            {foreign_keys_str}\n
            {primary_keys_str}\n
            问题: {user_question}
            SQLite SQL QUERY:{answer3_txt}
            NOTE! 请保证你的输出只有SQL语句，不需要其他任何修饰词！！！
            
            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
            
        elif question_type == 'multiple_choice':
            options = f'''A.{current_user_question['optionA']}
            B.{current_user_question['optionB']}
            C.{current_user_question['optionC']}
            D.{current_user_question['optionD']}
            '''
            system_prompt += f'''
            
            确定 SQL 关键字和子句以完成特定 SQL 任务或定义。按照以下步骤操作：
            1.仔细阅读与 SQL 相关的问题，以理解需求。
            2.查看提供的选项，确定哪个选项正确表示执行所描述任务所需的 SQL 语法或关键字。
            3.选择最符合所描述 SQL 命令或概念的选项。
            请对每个提供的输入执行这些步骤，以确保准确理解和应用 SQL 语法。你返回的答案只包括正确选项的字母，即 'A'、'B'、'C' 或 'D'，不需要任何标点符号或解释。
            '''
            user_prompt = f'''
            ##Question
            {user_question}
            {options}. 
            你只能选择一个最合适的答案。请参考以下示例：
            ##Example
            Question: 下列哪种JOIN操作不返回在两个表中匹配行的结果？ A.INNER JOIN B.LEFT JOIN C.RIGHT JOIN D.FULL JOIN
            A
            Question: 使用SQL语句TRUNCATE TABLE主要执行哪类功能？ A.数据查询 B.数据操纵 C.数据定义 D.数据控制
            C
            '''
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
        elif question_type == 'true_false_question':
            system_prompt = '''
            You are an expert in the field of databases.
            The answer you return can only be \"Ture\" or \"False\" without any punctuation or explanation.
            '''
            user_prompt = f'''
            The true or false question is: {user_question}. 
            Please verify the authenticity of the issue and print the answer.\nPlease refer to the following examples:\nQuestion: 在SQL中，'HAVING'子句可以用于聚合前的数据过滤。\nFalse\nQuestion: SQL的'CHECK'约束用于限制列中值的范围。\nTrue
            '''
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
        return messages
        
        
    # 此方法会被跑分服务器调用， messages 选手的 construct_prompt() 返回的结果
    # 请不要对此函数做任何改动
    # self.run_inference_llm(messages)
    # def run_inference_llm(self, messages):
    #     pass
