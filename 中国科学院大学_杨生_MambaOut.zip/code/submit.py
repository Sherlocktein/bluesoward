import json

# 此类会被跑分服务器继承， 可以在类中自由添加自己的prompt构建逻辑, 除了parse_table 和 run_inference_llm 两个方法不可改动
# 注意千万不可修改类名和下面已提供的三个函数名称和参数， 这三个函数都会被跑分服务器调用
class submission():
    def __init__(self, table_meta_path):
        self.table_meta_path = table_meta_path

    # 此函数不可改动, 与跑分服务器端逻辑一致， 返回值 grouped_by_db_id 是数据库的元数据（包含所有验证测试集用到的数据库）
    # 请不要对此函数做任何改动
    def parse_table(self, table_meta_path):
        with open(table_meta_path,'r') as db_meta:
            db_meta_info = json.load(db_meta)
        # 创建一个空字典来存储根据 db_id 分类的数据
        grouped_by_db_id = {}

        # 遍历列表中的每个字典
        for item in db_meta_info:
            # 获取当前字典的 db_id
            db_id = item['db_id']
            
            # 如果 db_id 已存在于字典中，将当前字典追加到对应的列表
            if db_id in grouped_by_db_id:
                grouped_by_db_id[db_id].append(item)
            # 如果 db_id 不在字典中，为这个 db_id 创建一个新列表
            else:
                grouped_by_db_id[db_id] = [item]
        return grouped_by_db_id

    # 此为选手主要改动的逻辑， 此函数会被跑分服务器调用，用来构造最终输出给模型的prompt， 并对模型回复进行打分。
    # 当前提供了一个最基础的prompt模版， 选手需要对其进行改进
    def construct_prompt(self, current_user_question):
        question_type = current_user_question['question_type']
        user_question = current_user_question['user_question']
        system_prompt = f'''
        You are an expert in the field of databases. 
        '''
        if question_type == 'text2sql':
            system_prompt += f'''
            
             Translate the provided natural language queries about different databases into SQL queries. Ensure the SQL queries accurately reflect the conditions and intentions of the natural language questions. Here are the steps:
            1. Read the natural language question carefully.
            2. Identify the key elements such as column names, conditions, and sorting requirements from the question.
            3. Write the SQL query using the appropriate SQL syntax to extract the relevant data from the database.
            4. Validate the SQL query to ensure it matches the intent of the natural language question and targets the correct database. 
            Note: The answer you returned only contains the complete SQL code in a line and does not contain any other descriptive statements.
            At last Translate this sentence into one line without changing the line.
            
            '''
            current_db_id = current_user_question['db_id']
            cur_db_info = self.parse_table(self.table_meta_path)[current_db_id]
            user_prompt = f"The format of the database is: {cur_db_info} and I would like to inquire about: {user_question}."
        elif question_type == 'multiple_choice':
            options = "A." + current_user_question['optionA'] + "B." + current_user_question['optionB']+ "C." + current_user_question['optionC']+ "D." + current_user_question['optionD']
            system_prompt += f'''
            Determine the correct SQL keywords and clauses from multiple-choice options given specific SQL tasks or definitions. Follow these steps:

            1.Carefully read the SQL-related question to understand the requirement.
            2.Review the options provided and identify which one correctly represents the SQL syntax or keyword needed to perform the described task.
            3.Choose the option that best fits the SQL command or concept described in the question.
            Please execute these steps for each of the provided inputs to ensure accurate understanding and application of SQL syntax.
            The answer you returned only includes the letter of the correct option, namely 'A', 'B', 'C', or 'D' without any punctuation or explanation.
            '''
            user_prompt = f"The multiple-choice question is: {user_question} and the options are: {options}.\nPlease refer to the following examples:\nQuestion: 下列哪种JOIN操作不返回在两个表中匹配行的结果？ A.INNER JOIN B.LEFT JOIN C.RIGHT JOIN D.FULL JOIN\nA\nQuestion: 使用SQL语句TRUNCATE TABLE主要执行哪类功能？ A.数据查询 B.数据操纵 C.数据定义 D.数据控制\nC\nQuestion: 在SQL中，哪一个关键字用来从数据库中删除数据？ A.REMOVE B.DROP C.DELETE. D.CUT \nC  "
        elif question_type == 'true_false_question':
            system_prompt += f''' 
            Evaluate the accuracy of statements related to SQL syntax and operations. Follow these steps:

            1.Read each statement carefully to understand the SQL concept or operation being described.
            2.Determine whether the statement is correct based on standard SQL practices and definitions.
            3.Confirm the accuracy by selecting "True" if the statement correctly describes the SQL feature or operation, and "False" if it does not.
            Please follow these steps for each of the provided statements to ensure a clear understanding and correct evaluation of SQL functionalities.
            The answer you return can only be \"Ture\" or \"False\" without any punctuation or explanation.
            '''
            user_prompt = f"The true or false question is: {user_question}. Please verify the authenticity of the issue and print the answer.\nPlease refer to the following examples:\nQuestion: 在SQL中，'HAVING'子句可以用于聚合前的数据过滤。\nFalse\nQuestion: SQL的'CHECK'约束用于限制列中值的范围。\nTrue"

        messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
        ]
        return messages

    # 此方法会被跑分服务器调用， messages 选手的 construct_prompt() 返回的结果
    # 请不要对此函数做任何改动
    def run_inference_llm(self, messages):
        pass