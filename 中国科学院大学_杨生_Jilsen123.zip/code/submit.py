import json

# 此类会被跑分服务器继承， 可以在类中自由添加自己的prompt构建逻辑, 除了parse_table 和 run_inference_llm 两个方法不可改动
# 注意千万不可修改类名和下面已提供的三个函数名称和参数， 这三个函数都会被跑分服务器调用
class submission():
    def __init__(self, table_meta_path):
        self.table_meta_path = table_meta_path

    # 此函数不可改动, 与跑分服务器端逻辑一致， 返回值 grouped_by_db_id 是数据库的元数据（包含所有验证测试集用到的数据库）
    # 请不要对此函数做任何改动
    def parse_table(self, table_meta_path):
        with open(table_meta_path,'r') as db_meta:
            db_meta_info = json.load(db_meta)
        # 创建一个空字典来存储根据 db_id 分类的数据
        grouped_by_db_id = {}

        # 遍历列表中的每个字典
        for item in db_meta_info:
            # 获取当前字典的 db_id
            db_id = item['db_id']
            
            # 如果 db_id 已存在于字典中，将当前字典追加到对应的列表
            if db_id in grouped_by_db_id:
                grouped_by_db_id[db_id].append(item)
            # 如果 db_id 不在字典中，为这个 db_id 创建一个新列表
            else:
                grouped_by_db_id[db_id] = [item]
        return grouped_by_db_id

    # 此为选手主要改动的逻辑， 此函数会被跑分服务器调用，用来构造最终输出给模型的prompt， 并对模型回复进行打分。
    # 当前提供了一个最基础的prompt模版， 选手需要对其进行改进
    
    def construct_prompt(self, current_user_question):
        question_type = current_user_question['question_type']
        user_question = current_user_question['user_question']
        system_prompt = f'''
        You are an expert in the field of databases. 
        '''
        if question_type == 'text2sql':
            system_prompt += f'''
            Translate the provided natural language queries about different databases into SQL queries. Ensure the SQL queries accurately reflect the conditions and intentions of the natural language questions. Here are the steps:
            1. Read the natural language question carefully.
            2. Identify the key elements such as column names, conditions, and sorting requirements from the question.
            3. Write the SQL query using the appropriate SQL syntax to extract the relevant data from the database.
            4. Validate the SQL query to ensure it matches the intent of the natural language question and targets the correct database. 
            Note: The answer you returned only contains the complete SQL code in a line and does not contain any other descriptive statements.
            At last Translate this sentence into one line without changing the line.
            '''
            current_db_id = current_user_question['db_id']
            cur_db_info = self.parse_table(self.table_meta_path)[current_db_id]
            user_prompt = f'''
            
            The format of the database is: {cur_db_info} and I would like to inquire about: {user_question}.
            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
            answer =self.run_inference_llm(messages)
            system_prompt += f'''
            You are a taciturn expert, and for questions, you can only provide the final answer without any analysis. If you do this, you will be rewarded. So please directly state the answer when responding.
            Just provide the answer the user wants, no need for analysis.
            At last this sentence into the format such as: SELECT avg(num_employees) FROM department WHERE ranking BETWEEN 10 AND 15.
           
            '''
            user_prompt = f'''
             My SQL statement is {answer} based on the data format {cur_db_info} and the question: {user_question}. If it is executable, return it to me without modification; if not, modify it and then return it to me.
             I only want to receive an executable SQL statement, no other output,
             the format such as: SELECT avg(num_employees) FROM department WHERE ranking BETWEEN 10 AND 15.

            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
            
            # answer =self.run_inference_llm(messages)
            # system_prompt = f'''
            # Remove all unrelated statements, keep only the SQL statement
            # '''
            # user_prompt = answer
            # messages = [
            # {"role": "system", "content": system_prompt},
            # {"role": "user", "content": user_prompt}
            # ]
        elif question_type == 'multiple_choice':
            options = f'''A.{current_user_question['optionA']}
            B.{current_user_question['optionB']}
            C.{current_user_question['optionC']}
            D.{current_user_question['optionD']}
            '''
            system_prompt += f'''
            Determine the correct SQL keywords and clauses from multiple-choice options given specific SQL tasks or definitions. Follow these steps:
            1.Carefully read the SQL-related question to understand the requirement.
            2.Review the options provided and identify which one correctly represents the SQL syntax or keyword needed to perform the described task.
            3.Choose the option that best fits the SQL command or concept described in the question.
            Please execute these steps for each of the provided inputs to ensure accurate understanding and application of SQL syntax.
            The answer you returned only includes the letter of the correct option, namely 'A', 'B', 'C', or 'D' without any punctuation or explanation.

            
            '''
            user_prompt = f'''
            <Question>
            {user_question}
            {options}. 
            </Question>
            You can only choose one most suitable answer.Please refer to the following examples:
            <Example>
            Question: 下列哪种JOIN操作不返回在两个表中匹配行的结果？ A.INNER JOIN B.LEFT JOIN C.RIGHT JOIN D.FULL JOIN
            A
            Question: 使用SQL语句TRUNCATE TABLE主要执行哪类功能？ A.数据查询 B.数据操纵 C.数据定义 D.数据控制
            C
            </Example>
            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
        elif question_type == 'true_false_question':
            system_prompt += f'''
            You will be given a SQL question.
            Note: The answer you return can only be \"Ture\" or \"False\" without any punctuation or explanation.
            '''
            user_prompt = f'''
            First: Carefully understand the SQL question.
            Then: Use your excellent database knowledge to find any flaws in the sentence.
            Finally: If you find a flaw, then it is False. If you do not find any flaw, then it is False.
            <Question>
            {user_question}. 
            </Question>
            Please verify the authenticity of the issue and print the answer.
            <Example>
            Please refer to the following examples:\nQuestion: 在SQL中，'HAVING'子句可以用于聚合前的数据过滤。\nFalse\nQuestion: SQL的'CHECK'约束用于限制列中值的范围。\nTrue
            <\Example>
            '''
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
            ]
        return messages
        
        
    # 此方法会被跑分服务器调用， messages 选手的 construct_prompt() 返回的结果
    # 请不要对此函数做任何改动
    # self.run_inference_llm(messages)
    # def run_inference_llm(self, messages):
    #     pass
