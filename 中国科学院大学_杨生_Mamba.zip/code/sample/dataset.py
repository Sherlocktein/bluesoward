import json

# 读取JSONL文件并转换为列表
def read_jsonl(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            data.append(json.loads(line))
    return data

# 加载问题和答案数据
questions = read_jsonl('/media/ys/qwen/lanjian/baseline/sample/1.1.jsonl')
answers = read_jsonl('/media/ys/qwen/lanjian/baseline/sample/1.jsonl')

# 创建一个字典，以question_id为键，答案为值
answers_dict = {item['question_id']: item['answer'] for item in answers}

# 创建新的数据结构
new_data = []
for question in questions:
    qid = question['question_id']
    answer = answers_dict.get(qid)
    if answer:
        new_entry = {
            "input": f"{question['user_question']}",
            "target": f"{answer}"
        }
        new_data.append(new_entry)

# 将新数据写入JSONL文件
with open('merged_data.jsonl', 'w', encoding='utf-8') as f:
    for entry in new_data:
        json.dump(entry, f, ensure_ascii=False)
        f.write('\n')  # 写入换行符来分隔记录

print("合并完成，并已写入到 'merged_data.jsonl'")
